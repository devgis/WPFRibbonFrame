﻿using System;

namespace Sample.Core
{
    public interface IWeight
    {
    }
}