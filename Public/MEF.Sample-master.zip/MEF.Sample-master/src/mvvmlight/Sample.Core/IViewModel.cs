﻿namespace Sample.Core
{
    public interface IViewModel
    {
    }
}