﻿namespace Sample.Core
{
    public interface IView
    {
    }
}