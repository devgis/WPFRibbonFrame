﻿using System.Windows.Controls;

namespace BlankApp.Modules.ModuleB.Views
{
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
