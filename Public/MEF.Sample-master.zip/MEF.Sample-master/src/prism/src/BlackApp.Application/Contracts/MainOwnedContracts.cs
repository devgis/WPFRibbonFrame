﻿namespace BlackApp.Application.Contracts
{
    /// <summary>
    /// 一级菜单
    /// </summary>
    public class MainOwnedContracts
    {
        public const string A = "菜单1";
        public const string B = "菜单2";
    }
}
