﻿namespace BlackApp.Application.Contracts
{
    public class DialogContracts
    {
        public const string Notification = "NotificationDialog";
        public const string Exception = "ExceptionDialog";
    }
}
