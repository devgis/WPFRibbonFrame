﻿namespace BlackApp.Application.Contracts
{
    public class RegionContracts
    {
        public const string TopContentRegion = "TopContentRegion";
        public const string SideContentRegion = "SideContentRegion";
        public const string MainContentRegion = "MainContentRegion";
    }
}
