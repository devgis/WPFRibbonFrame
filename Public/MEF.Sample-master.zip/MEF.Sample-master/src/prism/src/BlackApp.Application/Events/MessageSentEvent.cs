﻿using Prism.Events;

namespace BlackApp.Application.Events
{
    public class MessageSentEvent : PubSubEvent<string>
    {
    }
}
