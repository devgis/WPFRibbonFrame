﻿using System.Windows;
using System.Windows.Controls;

namespace BlankApp.Themes.Extensions
{
    public static class ViewExtension
    {
        public static string GetTitle(DependencyObject obj)
        {
            return (string)obj.GetValue(TitleProperty);
        }

        public static void SetTitle(DependencyObject obj, string value)
        {
            obj.SetValue(TitleProperty, value);
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.RegisterAttached("Title", typeof(string), typeof(ViewExtension), new PropertyMetadata(default));
    }
}
